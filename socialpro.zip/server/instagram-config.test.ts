import { describe, it, expect } from "vitest";
import { ENV } from "./_core/env";

describe("Instagram Configuration", () => {
  it("should have all required Instagram credentials configured", () => {
    expect(ENV.instagramAppId).toBeTruthy();
    expect(ENV.instagramAppSecret).toBeTruthy();
    expect(ENV.instagramRedirectUri).toBeTruthy();
  });

  it("should have valid redirect URI format", () => {
    expect(ENV.instagramRedirectUri).toMatch(/^https?:\/\//);
    expect(ENV.instagramRedirectUri).toContain("callback");
  });

  it("should have Instagram App ID in correct format", () => {
    // Instagram App IDs are numeric
    expect(ENV.instagramAppId).toMatch(/^\d+$/);
  });

  it("should have Instagram App Secret in correct format", () => {
    // Instagram App Secrets are typically 32 character hex strings
    expect(ENV.instagramAppSecret.length).toBeGreaterThan(20);
  });
});
