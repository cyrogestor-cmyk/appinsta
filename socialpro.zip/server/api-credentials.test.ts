import { describe, it, expect } from "vitest";
import { ENV } from "./_core/env";

describe("API Credentials Validation", () => {
  it("should have Instagram credentials configured", () => {
    expect(ENV.instagramAppId).toBeDefined();
    expect(ENV.instagramAppId).toMatch(/^\d+$/);
    expect(ENV.instagramAppSecret).toBeDefined();
    expect(ENV.instagramAppSecret.length).toBeGreaterThan(20);
  });

  it("should have Google OAuth credentials configured", () => {
    expect(ENV.googleClientId).toBeDefined();
    expect(ENV.googleClientId).toContain("apps.googleusercontent.com");
    expect(ENV.googleClientSecret).toBeDefined();
    expect(ENV.googleClientSecret.length).toBeGreaterThan(20);
  });

  it("should have MisticPay credentials configured", () => {
    expect(ENV.misticpayClientId).toBeDefined();
    expect(ENV.misticpayClientId).toMatch(/^ci_/);
    expect(ENV.misticpayClientSecret).toBeDefined();
    expect(ENV.misticpayClientSecret).toMatch(/^cs_/);
    expect(ENV.misticpayApiUrl).toBeDefined();
    expect(ENV.misticpayApiUrl).toContain("misticpay.com");
  });

  it("should have redirect URIs configured", () => {
    expect(ENV.instagramRedirectUri).toBeDefined();
    expect(ENV.instagramRedirectUri).toContain("callback");
    expect(ENV.misticpayWebhookUrl).toBeDefined();
    expect(ENV.misticpayWebhookUrl).toContain("webhooks/misticpay");
  });
});
