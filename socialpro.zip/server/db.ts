import { eq, and, gte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, instagramAccounts, userPlans, payments, instagramMetrics } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get user's Instagram accounts
 */
export async function getUserInstagramAccounts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(instagramAccounts).where(eq(instagramAccounts.userId, userId));
}

/**
 * Get or create user plan
 */
export async function getOrCreateUserPlan(userId: number) {
  const db = await getDb();
  if (!db) return null;
  
  const existing = await db.select().from(userPlans).where(eq(userPlans.userId, userId)).limit(1);
  if (existing.length > 0) return existing[0];
  
  // Create default free plan
  await db.insert(userPlans).values({
    userId,
    planType: 'free',
    maxAccounts: 1,
    maxApiCalls: 1000,
    monthlyPrice: 0,
  });
  
  const created = await db.select().from(userPlans).where(eq(userPlans.userId, userId)).limit(1);
  return created[0] || null;
}

/**
 * Get user's metrics for an Instagram account
 */
export async function getAccountMetrics(accountId: number, days: number = 30) {
  const db = await getDb();
  if (!db) return [];
  
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);
  
  return db.select().from(instagramMetrics)
    .where(and(
      eq(instagramMetrics.accountId, accountId),
      gte(instagramMetrics.date, startDate)
    ));
}

/**
 * Create payment record
 */
export async function createPayment(userId: number, planType: 'free' | 'pro' | 'business', amountCents: number, transactionId: string) {
  const db = await getDb();
  if (!db) return null;
  
  await db.insert(payments).values({
    userId,
    planType,
    amountCents,
    transactionId,
    status: 'pending',
  });
  
  return db.select().from(payments).where(eq(payments.transactionId, transactionId)).limit(1).then(r => r[0] || null);
}
