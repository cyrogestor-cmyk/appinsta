export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  cookieSecret: process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
  // Instagram API
  instagramAppId: process.env.INSTAGRAM_APP_ID ?? "",
  instagramAppSecret: process.env.INSTAGRAM_APP_SECRET ?? "",
  instagramRedirectUri: process.env.INSTAGRAM_REDIRECT_URI ?? "",
  // Google OAuth
  googleClientId: process.env.GOOGLE_CLIENT_ID ?? "",
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
  // MisticPay
  misticpayClientId: process.env.MISTICPAY_CLIENT_ID ?? "",
  misticpayClientSecret: process.env.MISTICPAY_CLIENT_SECRET ?? "",
  misticpayApiUrl: process.env.MISTICPAY_API_URL ?? "",
  misticpayWebhookUrl: process.env.MISTICPAY_WEBHOOK_URL ?? "",
};
