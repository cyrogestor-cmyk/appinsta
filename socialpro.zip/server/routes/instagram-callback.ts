import type { Express, Request, Response } from "express";
import { exchangeCodeForToken, getUserProfile } from "../services/instagram-api";
import { getDb } from "../db";
import { instagramAccounts } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export function registerInstagramCallbackRoute(app: Express) {
  app.get("/api/auth/instagram/callback", async (req: Request, res: Response) => {
    try {
      const code = req.query.code as string;

      if (!code) {
        throw new Error("Authorization code is required");
      }

      // Exchange code for access token
      const { accessToken } = await exchangeCodeForToken(code);

      // Get user profile
      const profile = await getUserProfile(accessToken);

      // Store account in database (this will be done via tRPC in the frontend)
      // For now, just return the data to the popup

      // Return a success page that closes the popup and notifies the parent
      res.send(`
        <html>
          <head>
            <title>Instagram Connected</title>
            <style>
              body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                margin: 0;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              }
              .container {
                text-align: center;
                background: white;
                padding: 40px;
                border-radius: 12px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.2);
              }
              h1 { color: #10b981; margin: 0 0 10px 0; }
              p { color: #666; margin: 5px 0; }
            </style>
          </head>
          <body>
            <div class="container">
              <h1>✅ Conta Conectada!</h1>
              <p>@${profile.username}</p>
              <p style="font-size: 12px; color: #999;">Fechando em 2 segundos...</p>
            </div>
            <script>
              // Notify parent window
              if (window.opener) {
                window.opener.postMessage({
                  type: 'instagram-connected',
                  success: true,
                  data: {
                    instagramId: '${profile.id}',
                    username: '${profile.username}',
                    accessToken: '${accessToken}',
                    followers: ${profile.followers_count},
                    bio: '${profile.biography?.replace(/'/g, "\\\\'") || ''}',
                    profilePictureUrl: '${profile.profile_picture_url}'
                  }
                }, '*');
              }
              // Close popup after 2 seconds
              setTimeout(() => window.close(), 2000);
            </script>
          </body>
        </html>
      `);
    } catch (error) {
      console.error("[Instagram Callback] Error:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      res.send(`
        <html>
          <head>
            <title>Connection Failed</title>
            <style>
              body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                margin: 0;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              }
              .container {
                text-align: center;
                background: white;
                padding: 40px;
                border-radius: 12px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.2);
              }
              h1 { color: #ef4444; margin: 0 0 10px 0; }
              p { color: #666; margin: 5px 0; }
            </style>
          </head>
          <body>
            <div class="container">
              <h1>❌ Erro na Conexão</h1>
              <p>${errorMessage}</p>
              <p style="font-size: 12px; color: #999;">Fechando em 3 segundos...</p>
            </div>
            <script>
              // Notify parent window of error
              if (window.opener) {
                window.opener.postMessage({
                  type: 'instagram-connected',
                  success: false,
                  error: '${errorMessage}'
                }, '*');
              }
              // Close popup after 3 seconds
              setTimeout(() => window.close(), 3000);
            </script>
          </body>
        </html>
      `);
    }
  });
}
