import { ENV } from "../_core/env";

/**
 * Create a PIX payment transaction
 */
export async function createPixPayment(params: {
  amount: number;
  description: string;
  externalId: string;
  customerEmail: string;
  customerName: string;
}): Promise<{
  transactionId: string;
  qrCode: string;
  copyPaste: string;
  expiresAt: string;
}> {
  try {
    const response = await fetch(`${ENV.misticpayApiUrl}/transactions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ENV.misticpayClientId}:${ENV.misticpayClientSecret}`,
      },
      body: JSON.stringify({
        amount: Math.round(params.amount * 100), // Convert to cents
        description: params.description,
        externalId: params.externalId,
        paymentMethod: "pix",
        customer: {
          email: params.customerEmail,
          name: params.customerName,
        },
        webhook: {
          url: ENV.misticpayWebhookUrl,
          events: ["payment.completed", "payment.failed"],
        },
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`MisticPay API error: ${error}`);
    }

    const data = await response.json();

    return {
      transactionId: data.id,
      qrCode: data.qr_code,
      copyPaste: data.copy_paste,
      expiresAt: data.expires_at,
    };
  } catch (error) {
    console.error("[MisticPay] Create payment error:", error);
    throw error;
  }
}

/**
 * Check payment status
 */
export async function checkPaymentStatus(transactionId: string): Promise<{
  status: "pending" | "completed" | "failed" | "expired";
  amount: number;
  paidAt?: string;
}> {
  try {
    const response = await fetch(`${ENV.misticpayApiUrl}/transactions/${transactionId}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${ENV.misticpayClientId}:${ENV.misticpayClientSecret}`,
      },
    });

    if (!response.ok) {
      throw new Error(`MisticPay API error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      status: data.status,
      amount: data.amount / 100, // Convert from cents
      paidAt: data.paid_at,
    };
  } catch (error) {
    console.error("[MisticPay] Check status error:", error);
    throw error;
  }
}

/**
 * Verify webhook signature
 */
export function verifyWebhookSignature(
  payload: string,
  signature: string
): boolean {
  try {
    // In production, use HMAC-SHA256 to verify
    // For now, basic validation
    return signature && payload ? true : false;
  } catch (error) {
    console.error("[MisticPay] Verify signature error:", error);
    return false;
  }
}

/**
 * Refund a payment
 */
export async function refundPayment(
  transactionId: string,
  amount?: number
): Promise<{
  refundId: string;
  status: string;
}> {
  try {
    const response = await fetch(`${ENV.misticpayApiUrl}/transactions/${transactionId}/refund`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${ENV.misticpayClientId}:${ENV.misticpayClientSecret}`,
      },
      body: JSON.stringify({
        amount: amount ? Math.round(amount * 100) : undefined,
      }),
    });

    if (!response.ok) {
      throw new Error(`MisticPay API error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      refundId: data.refund_id,
      status: data.status,
    };
  } catch (error) {
    console.error("[MisticPay] Refund error:", error);
    throw error;
  }
}
