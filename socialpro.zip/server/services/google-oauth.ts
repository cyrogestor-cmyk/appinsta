import { ENV } from "../_core/env";

const GOOGLE_OAUTH_BASE = "https://oauth2.googleapis.com";
const GOOGLE_API_BASE = "https://www.googleapis.com";

/**
 * Get Google OAuth authorization URL
 */
export function getAuthorizationUrl(redirectUri: string, state: string): string {
  const params = new URLSearchParams({
    client_id: ENV.googleClientId,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "openid email profile",
    state,
  });

  return `${GOOGLE_OAUTH_BASE}/o/oauth2/v2/auth?${params.toString()}`;
}

/**
 * Exchange authorization code for access token
 */
export async function exchangeCodeForToken(
  code: string,
  redirectUri: string
): Promise<{
  accessToken: string;
  idToken: string;
  refreshToken?: string;
  expiresIn: number;
}> {
  try {
    const response = await fetch(`${GOOGLE_OAUTH_BASE}/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: ENV.googleClientId,
        client_secret: ENV.googleClientSecret,
        code,
        grant_type: "authorization_code",
        redirect_uri: redirectUri,
      }).toString(),
    });

    if (!response.ok) {
      throw new Error(`Google OAuth error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      accessToken: data.access_token,
      idToken: data.id_token,
      refreshToken: data.refresh_token,
      expiresIn: data.expires_in,
    };
  } catch (error) {
    console.error("[Google OAuth] Exchange code error:", error);
    throw error;
  }
}

/**
 * Get user info from Google
 */
export async function getUserInfo(accessToken: string): Promise<{
  id: string;
  email: string;
  name: string;
  picture: string;
  emailVerified: boolean;
}> {
  try {
    const response = await fetch(`${GOOGLE_API_BASE}/oauth2/v2/userinfo`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error(`Google API error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      id: data.id,
      email: data.email,
      name: data.name,
      picture: data.picture,
      emailVerified: data.verified_email,
    };
  } catch (error) {
    console.error("[Google OAuth] Get user info error:", error);
    throw error;
  }
}

/**
 * Refresh access token
 */
export async function refreshAccessToken(refreshToken: string): Promise<{
  accessToken: string;
  expiresIn: number;
}> {
  try {
    const response = await fetch(`${GOOGLE_OAUTH_BASE}/token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: ENV.googleClientId,
        client_secret: ENV.googleClientSecret,
        refresh_token: refreshToken,
        grant_type: "refresh_token",
      }).toString(),
    });

    if (!response.ok) {
      throw new Error(`Google OAuth error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      accessToken: data.access_token,
      expiresIn: data.expires_in,
    };
  } catch (error) {
    console.error("[Google OAuth] Refresh token error:", error);
    throw error;
  }
}

/**
 * Verify ID token
 */
export async function verifyIdToken(idToken: string): Promise<{
  sub: string;
  email: string;
  name: string;
  picture: string;
  emailVerified: boolean;
}> {
  try {
    const response = await fetch(
      `${GOOGLE_API_BASE}/oauth2/v1/tokeninfo?id_token=${idToken}`
    );

    if (!response.ok) {
      throw new Error(`Google OAuth error: ${response.statusText}`);
    }

    const data = await response.json();

    return {
      sub: data.sub,
      email: data.email,
      name: data.name,
      picture: data.picture,
      emailVerified: data.email_verified,
    };
  } catch (error) {
    console.error("[Google OAuth] Verify ID token error:", error);
    throw error;
  }
}
