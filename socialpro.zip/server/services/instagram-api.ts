import { ENV } from "../_core/env";

const INSTAGRAM_API_BASE = "https://graph.instagram.com/v20.0";

/**
 * Exchange authorization code for access token
 */
export async function exchangeCodeForToken(code: string): Promise<{
  accessToken: string;
  userId: string;
}> {
  try {
    // Use Facebook Graph API endpoint for token exchange
    const response = await fetch(`https://graph.instagram.com/v20.0/oauth/access_token`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: ENV.instagramAppId,
        client_secret: ENV.instagramAppSecret,
        grant_type: "authorization_code",
        redirect_uri: ENV.instagramRedirectUri,
        code,
      }).toString(),
    });

    const data = await response.json();
    
    if (!response.ok || data.error) {
      console.error("[Instagram API] Error response:", data);
      throw new Error(`Instagram API error: ${data.error?.message || response.statusText}`);
    }

    return {
      accessToken: data.access_token,
      userId: data.user_id || data.id,
    };
  } catch (error) {
    console.error("[Instagram API] Exchange code error:", error);
    throw error;
  }
}

/**
 * Get user profile information
 */
export async function getUserProfile(accessToken: string): Promise<{
  id: string;
  username: string;
  name: string;
  biography: string;
  profile_picture_url: string;
  followers_count: number;
  follows_count: number;
  media_count: number;
}> {
  try {
    const response = await fetch(
      `${INSTAGRAM_API_BASE}/me?fields=id,username,name,biography,profile_picture_url,followers_count,follows_count,media_count&access_token=${accessToken}`
    );

    if (!response.ok) {
      throw new Error(`Instagram API error: ${response.statusText}`);
    }

    return response.json();
  } catch (error) {
    console.error("[Instagram API] Get profile error:", error);
    throw error;
  }
}

/**
 * Get user's media (posts)
 */
export async function getUserMedia(
  accessToken: string,
  limit: number = 10
): Promise<Array<{
  id: string;
  caption: string;
  media_type: string;
  media_url: string;
  timestamp: string;
  like_count: number;
  comments_count: number;
}>> {
  try {
    const response = await fetch(
      `${INSTAGRAM_API_BASE}/me/media?fields=id,caption,media_type,media_url,timestamp,like_count,comments_count&limit=${limit}&access_token=${accessToken}`
    );

    if (!response.ok) {
      throw new Error(`Instagram API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.data || [];
  } catch (error) {
    console.error("[Instagram API] Get media error:", error);
    throw error;
  }
}

/**
 * Get insights for a media item
 */
export async function getMediaInsights(
  mediaId: string,
  accessToken: string
): Promise<{
  impressions: number;
  reach: number;
  engagement: number;
}> {
  try {
    const response = await fetch(
      `${INSTAGRAM_API_BASE}/${mediaId}/insights?metric=impressions,reach,engagement&access_token=${accessToken}`
    );

    if (!response.ok) {
      throw new Error(`Instagram API error: ${response.statusText}`);
    }

    const data = await response.json();
    const insights: any = {};

    data.data?.forEach((metric: any) => {
      insights[metric.name] = metric.values[0]?.value || 0;
    });

    return {
      impressions: insights.impressions || 0,
      reach: insights.reach || 0,
      engagement: insights.engagement || 0,
    };
  } catch (error) {
    console.error("[Instagram API] Get insights error:", error);
    throw error;
  }
}

/**
 * Refresh access token
 */
export async function refreshAccessToken(accessToken: string): Promise<string> {
  try {
    const response = await fetch(
      `${INSTAGRAM_API_BASE}/refresh_access_token?grant_type=ig_refresh_token&access_token=${accessToken}`
    );

    if (!response.ok) {
      throw new Error(`Instagram API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.access_token;
  } catch (error) {
    console.error("[Instagram API] Refresh token error:", error);
    throw error;
  }
}
