import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb, getOrCreateUserPlan, createPayment } from "../db";
import { userPlans, payments } from "../../drizzle/schema";
import { createPixPayment, checkPaymentStatus } from "../services/misticpay-api";

const PLANS = {
  free: { name: "Grátis", maxAccounts: 1, maxApiCalls: 1000, priceCents: 0 },
  pro: { name: "Pro", maxAccounts: 5, maxApiCalls: 50000, priceCents: 2900 },
  business: { name: "Business", maxAccounts: 20, maxApiCalls: 500000, priceCents: 9900 },
};

export const paymentsRouter = router({
  /**
   * Create a PIX payment transaction
   */
  createTransaction: protectedProcedure
    .input(
      z.object({
        planId: z.enum(["free", "pro", "business"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const plan = PLANS[input.planId];
        if (!plan) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Invalid plan",
          });
        }

        // Free plan doesn't require payment
        if (plan.priceCents === 0) {
          const db = await getDb();
          if (!db) {
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "Database not available",
            });
          }

          await db
            .update(userPlans)
            .set({
              planType: "free",
              maxAccounts: plan.maxAccounts,
              maxApiCalls: plan.maxApiCalls,
              monthlyPrice: 0,
            })
            .where(eq(userPlans.userId, ctx.user.id));

          return {
            success: true,
            planId: input.planId,
            requiresPayment: false,
          };
        }

        // Create PIX payment via MisticPay
        const pixPayment = await createPixPayment({
          amount: plan.priceCents / 100,
          description: `SocialPRO - Plano ${plan.name}`,
          externalId: `user_${ctx.user.id}_${Date.now()}`,
          customerEmail: ctx.user.email || "user@socialpro.com",
          customerName: ctx.user.name || "SocialPRO User",
        });

        await createPayment(ctx.user.id, input.planId, plan.priceCents, pixPayment.transactionId);

        return {
          success: true,
          planId: input.planId,
          transactionId: pixPayment.transactionId,
          qrCode: pixPayment.qrCode,
          copyPaste: pixPayment.copyPaste,
          amount: plan.priceCents / 100,
          requiresPayment: true,
        };
      } catch (error) {
        console.error("[Payments] Create transaction error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create payment transaction",
        });
      }
    }),

  /**
   * Check payment status
   */
  checkStatus: protectedProcedure
    .input(
      z.object({
        transactionId: z.string(),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Database not available",
          });
        }

        const payment = await db
          .select()
          .from(payments)
          .where(eq(payments.transactionId, input.transactionId))
          .limit(1);

        if (!payment || payment.length === 0 || payment[0].userId !== ctx.user.id) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Payment not found",
          });
        }

        // Check status with MisticPay
        const misticpayStatus = await checkPaymentStatus(input.transactionId);

        return {
          status: misticpayStatus.status,
          amount: misticpayStatus.amount,
          planType: payment[0].planType,
          createdAt: payment[0].createdAt,
          paidAt: misticpayStatus.paidAt,
        };
      } catch (error) {
        console.error("[Payments] Check status error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to check payment status",
        });
      }
    }),

  /**
   * Get user's current plan
   */
  getCurrentPlan: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Database not available",
        });
      }

      const userPlan = await db
        .select()
        .from(userPlans)
        .where(eq(userPlans.userId, ctx.user.id))
        .limit(1);

      if (!userPlan || userPlan.length === 0) {
        // Create default free plan for new users
        await getOrCreateUserPlan(ctx.user.id);
        const plan = PLANS.free;
        return {
          planId: "free",
          name: plan.name,
          maxAccounts: plan.maxAccounts,
          maxApiCalls: plan.maxApiCalls,
          priceCents: 0,
          isActive: true,
        };
      }

      const plan = userPlan[0];
      const planInfo = PLANS[plan.planType];

      return {
        planId: plan.planType,
        name: planInfo.name,
        maxAccounts: plan.maxAccounts,
        maxApiCalls: plan.maxApiCalls,
        priceCents: plan.monthlyPrice,
        isActive: plan.isActive === 1,
        renewalDate: plan.renewalDate,
      };
    } catch (error) {
      console.error("[Payments] Get current plan error:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to get current plan",
      });
    }
  }),

  /**
   * Get available plans
   */
  getPlans: protectedProcedure.query(() => {
    return {
      plans: [
        {
          id: "free",
          name: PLANS.free.name,
          maxAccounts: PLANS.free.maxAccounts,
          maxApiCalls: PLANS.free.maxApiCalls,
          priceCents: PLANS.free.priceCents,
          features: ["1 conta Instagram", "1.000 chamadas API/mês", "Métricas básicas"],
        },
        {
          id: "pro",
          name: PLANS.pro.name,
          maxAccounts: PLANS.pro.maxAccounts,
          maxApiCalls: PLANS.pro.maxApiCalls,
          priceCents: PLANS.pro.priceCents,
          features: ["5 contas Instagram", "50.000 chamadas API/mês", "Análise avançada", "Suporte prioritário"],
        },
        {
          id: "business",
          name: PLANS.business.name,
          maxAccounts: PLANS.business.maxAccounts,
          maxApiCalls: PLANS.business.maxApiCalls,
          priceCents: PLANS.business.priceCents,
          features: ["20 contas Instagram", "500.000 chamadas API/mês", "IA avançada", "Suporte 24/7", "API customizada"],
        },
      ],
    };
  }),
});
