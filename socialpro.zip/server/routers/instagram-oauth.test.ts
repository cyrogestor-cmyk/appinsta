import { describe, it, expect } from "vitest";
import { appRouter } from "../routers";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return ctx;
}

describe("instagram.getAuthUrl", () => {
  it("should generate a valid Instagram OAuth URL", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    const result = await caller.instagram.getAuthUrl({
      redirectUri: "https://socialpro-bv6xpdvz.manus.space/api/auth/instagram/callback",
    });

    expect(result).toBeDefined();
    expect(result.authUrl).toBeDefined();
    expect(result.state).toBeDefined();
    expect(result.authUrl).toContain("https://api.instagram.com/oauth/authorize");
    expect(result.authUrl).toContain("client_id=");
    expect(result.authUrl).toContain("redirect_uri=");
    expect(result.authUrl).toContain("response_type=code");
  });

  it("should include correct scopes in OAuth URL", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    const result = await caller.instagram.getAuthUrl({
      redirectUri: "https://socialpro-bv6xpdvz.manus.space/api/auth/instagram/callback",
    });

    expect(result.authUrl).toContain("instagram_business_profile");
    expect(result.authUrl).toContain("instagram_graph_user_profile");
  });

  it("should reject invalid redirect URI", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    try {
      await caller.instagram.getAuthUrl({
        redirectUri: "not-a-valid-url",
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("BAD_REQUEST");
    }
  });
});

describe("instagram.listAccounts", () => {
  it("should return list of accounts for authenticated user", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.instagram.listAccounts();

    expect(result).toBeDefined();
    expect(result.accounts).toBeDefined();
    expect(Array.isArray(result.accounts)).toBe(true);
    // Accounts may exist from previous tests
    expect(result.accounts.length).toBeGreaterThanOrEqual(0);
  });

  it("should require authentication", async () => {
    const caller = appRouter.createCaller({} as TrpcContext);

    try {
      await caller.instagram.listAccounts();
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });
});
