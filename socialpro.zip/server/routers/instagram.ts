import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { eq } from "drizzle-orm";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { instagramAccounts, type InsertInstagramAccount } from "../../drizzle/schema";
import { exchangeCodeForToken, getUserProfile } from "../services/instagram-api";



export const instagramRouter = router({
  /**
   * Get authorization URL for Instagram OAuth flow
   */
  getAuthUrl: publicProcedure
    .input(
      z.object({
        redirectUri: z.string().url(),
      })
    )
    .query(({ input }) => {
      const instagramAppId = process.env.INSTAGRAM_APP_ID;
      console.log("[Instagram OAuth] App ID:", instagramAppId);
      if (!instagramAppId) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Instagram app ID not configured",
        });
      }

      const state = Buffer.from(JSON.stringify({
        userId: Date.now(),
        timestamp: new Date().toISOString(),
      })).toString("base64");

      // Use Facebook Graph API endpoint for Instagram OAuth
      const authUrl = new URL("https://api.instagram.com/oauth/authorize");
      authUrl.searchParams.append("client_id", instagramAppId);
      authUrl.searchParams.append("redirect_uri", input.redirectUri);
      // Use correct scopes for Instagram Graph API
      authUrl.searchParams.append("scope", "user_profile,user_media");
      authUrl.searchParams.append("response_type", "code");
      authUrl.searchParams.append("state", state);

      const finalUrl = authUrl.toString();
      console.log("[Instagram OAuth] Generated URL:", finalUrl);
      console.log("[Instagram OAuth] Redirect URI:", input.redirectUri);
      console.log("[Instagram OAuth] App ID used:", instagramAppId);
      console.log("[Instagram OAuth] Scopes:", "user_profile,user_media");
      return {
        authUrl: finalUrl,
        state,
      };
    }),

  /**
   * Handle OAuth callback and store Instagram account
   */
  handleCallback: protectedProcedure
    .input(
      z.object({
        code: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Database not available",
          });
        }

        // Exchange code for access token
        const { accessToken, userId } = await exchangeCodeForToken(input.code);

        // Get user profile
        const profile = await getUserProfile(accessToken);

        const accountData: InsertInstagramAccount = {
          userId: ctx.user.id,
          instagramId: profile.id,
          username: profile.username,
          accessToken,
          followers: profile.followers_count,
          bio: profile.biography,
          profilePictureUrl: profile.profile_picture_url,
        };

        await db.insert(instagramAccounts).values(accountData);

        return {
          success: true,
          account: {
            id: profile.id,
            username: profile.username,
          },
        };
      } catch (error) {
        console.error("[Instagram] Callback error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to connect Instagram account",
        });
      }
    }),

  /**
   * List connected Instagram accounts for the user
   */
  listAccounts: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Database not available",
        });
      }

      const accounts = await db
        .select()
        .from(instagramAccounts)
        .where(eq(instagramAccounts.userId, ctx.user.id));

      return {
        accounts: accounts.map((acc) => ({
          id: acc.id,
          instagramId: acc.instagramId,
          username: acc.username,
          followers: acc.followers,
          bio: acc.bio,
          profilePictureUrl: acc.profilePictureUrl,
          lastSyncedAt: acc.lastSyncedAt,
          createdAt: acc.createdAt,
        })),
      };
    } catch (error) {
      console.error("[Instagram] List accounts error:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to list Instagram accounts",
      });
    }
  }),

  /**
   * Disconnect an Instagram account
   */
  disconnectAccount: protectedProcedure
    .input(
      z.object({
        accountId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Database not available",
          });
        }

        const account = await db
          .select()
          .from(instagramAccounts)
          .where(eq(instagramAccounts.id, input.accountId))
          .limit(1);

        if (!account || account.length === 0 || account[0].userId !== ctx.user.id) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "You do not have permission to disconnect this account",
          });
        }

        await db.delete(instagramAccounts).where(eq(instagramAccounts.id, input.accountId));

        return {
          success: true,
        };
      } catch (error) {
        console.error("[Instagram] Disconnect error:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to disconnect Instagram account",
        });
      }
    }),
});
