import { describe, it, expect } from "vitest";
import { ENV } from "./_core/env";

describe("Instagram Credentials", () => {
  it("should have valid Instagram App ID", () => {
    expect(ENV.instagramAppId).toBeDefined();
    expect(ENV.instagramAppId).toMatch(/^\d{10,}$/);
    expect(ENV.instagramAppId).toBe("1448326733256264");
  });

  it("should have valid Instagram App Secret", () => {
    expect(ENV.instagramAppSecret).toBeDefined();
    expect(ENV.instagramAppSecret).toMatch(/^[a-f0-9]{32,}$/);
    expect(ENV.instagramAppSecret).toBe("400d7d3c812d9ead3f63d831265a1c88");
  });

  it("should have valid Instagram Redirect URI", () => {
    expect(ENV.instagramRedirectUri).toBeDefined();
    expect(ENV.instagramRedirectUri).toContain("https://");
    expect(ENV.instagramRedirectUri).toContain("/api/auth/instagram/callback");
  });

  it("should be able to construct OAuth URL", () => {
    const state = "test-state-123";
    const scopes = ["instagram_business_profile", "instagram_graph_user_profile"];
    
    const url = new URL("https://api.instagram.com/oauth/authorize");
    url.searchParams.append("client_id", ENV.instagramAppId);
    url.searchParams.append("redirect_uri", ENV.instagramRedirectUri);
    url.searchParams.append("scope", scopes.join(","));
    url.searchParams.append("response_type", "code");
    url.searchParams.append("state", state);

    const urlString = url.toString();
    expect(urlString).toContain(ENV.instagramAppId);
    // Redirect URI está encoded na URL, então verificamos a versão encoded
    expect(urlString).toContain("socialpro.manus.space");
    expect(urlString).toContain("instagram_business_profile");
  });
});
