CREATE TABLE `instagram_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`instagramId` varchar(64) NOT NULL,
	`username` varchar(255) NOT NULL,
	`accessToken` text NOT NULL,
	`followers` int DEFAULT 0,
	`bio` text,
	`profilePictureUrl` varchar(512),
	`lastSyncedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `instagram_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `instagram_accounts_instagramId_unique` UNIQUE(`instagramId`)
);
--> statement-breakpoint
CREATE TABLE `instagram_metrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountId` int NOT NULL,
	`date` timestamp NOT NULL,
	`impressions` int DEFAULT 0,
	`reach` int DEFAULT 0,
	`profileViews` int DEFAULT 0,
	`websiteClicks` int DEFAULT 0,
	`saves` int DEFAULT 0,
	`shares` int DEFAULT 0,
	`engagementRate` varchar(10),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `instagram_metrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`transactionId` varchar(255) NOT NULL,
	`planType` enum('free','pro','business') NOT NULL,
	`amountCents` int NOT NULL,
	`currency` varchar(3) DEFAULT 'BRL',
	`status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
	`paymentMethod` varchar(50) DEFAULT 'pix',
	`qrCode` text,
	`copyPaste` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`),
	CONSTRAINT `payments_transactionId_unique` UNIQUE(`transactionId`)
);
--> statement-breakpoint
CREATE TABLE `user_plans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`planType` enum('free','pro','business') NOT NULL DEFAULT 'free',
	`maxAccounts` int DEFAULT 1,
	`maxApiCalls` int DEFAULT 1000,
	`monthlyPrice` int DEFAULT 0,
	`isActive` int DEFAULT 1,
	`renewalDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_plans_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_plans_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `instagram_accounts` ADD CONSTRAINT `instagram_accounts_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `instagram_metrics` ADD CONSTRAINT `instagram_metrics_accountId_instagram_accounts_id_fk` FOREIGN KEY (`accountId`) REFERENCES `instagram_accounts`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `payments` ADD CONSTRAINT `payments_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_plans` ADD CONSTRAINT `user_plans_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;