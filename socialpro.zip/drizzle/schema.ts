import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Instagram Accounts table - stores connected Instagram accounts for each user
 */
export const instagramAccounts = mysqlTable("instagram_accounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  instagramId: varchar("instagramId", { length: 64 }).notNull().unique(),
  username: varchar("username", { length: 255 }).notNull(),
  accessToken: text("accessToken").notNull(),
  followers: int("followers").default(0),
  bio: text("bio"),
  profilePictureUrl: varchar("profilePictureUrl", { length: 512 }),
  lastSyncedAt: timestamp("lastSyncedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InstagramAccount = typeof instagramAccounts.$inferSelect;
export type InsertInstagramAccount = typeof instagramAccounts.$inferInsert;

/**
 * User Plans table - tracks subscription plans for each user
 */
export const userPlans = mysqlTable("user_plans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  planType: mysqlEnum("planType", ["free", "pro", "business"]).default("free").notNull(),
  maxAccounts: int("maxAccounts").default(1),
  maxApiCalls: int("maxApiCalls").default(1000),
  monthlyPrice: int("monthlyPrice").default(0),
  isActive: int("isActive").default(1),
  renewalDate: timestamp("renewalDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserPlan = typeof userPlans.$inferSelect;
export type InsertUserPlan = typeof userPlans.$inferInsert;

/**
 * Payments table - tracks all payment transactions
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  transactionId: varchar("transactionId", { length: 255 }).notNull().unique(),
  planType: mysqlEnum("planType", ["free", "pro", "business"]).notNull(),
  amountCents: int("amountCents").notNull(),
  currency: varchar("currency", { length: 3 }).default("BRL"),
  status: mysqlEnum("status", ["pending", "completed", "failed", "refunded"]).default("pending"),
  paymentMethod: varchar("paymentMethod", { length: 50 }).default("pix"),
  qrCode: text("qrCode"),
  copyPaste: text("copyPaste"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * Instagram Metrics table - stores daily/hourly metrics for each account
 */
export const instagramMetrics = mysqlTable("instagram_metrics", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull().references(() => instagramAccounts.id),
  date: timestamp("date").notNull(),
  impressions: int("impressions").default(0),
  reach: int("reach").default(0),
  profileViews: int("profileViews").default(0),
  websiteClicks: int("websiteClicks").default(0),
  saves: int("saves").default(0),
  shares: int("shares").default(0),
  engagementRate: varchar("engagementRate", { length: 10 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type InstagramMetric = typeof instagramMetrics.$inferSelect;
export type InsertInstagramMetric = typeof instagramMetrics.$inferInsert;