import { trpc } from "@/lib/trpc";

export const useInstagram = {
  getAuthUrl: trpc.instagram.getAuthUrl,
  handleCallback: trpc.instagram.handleCallback,
  listAccounts: trpc.instagram.listAccounts,
  disconnectAccount: trpc.instagram.disconnectAccount,
};
