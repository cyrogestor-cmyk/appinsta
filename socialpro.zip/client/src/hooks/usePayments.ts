import { trpc } from "@/lib/trpc";

export const usePayments = {
  createTransaction: trpc.payments.createTransaction,
  checkStatus: trpc.payments.checkStatus,
  getCurrentPlan: trpc.payments.getCurrentPlan,
  getPlans: trpc.payments.getPlans,
};
