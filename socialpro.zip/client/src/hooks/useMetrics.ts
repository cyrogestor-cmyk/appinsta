import { trpc } from "@/lib/trpc";

export const useMetrics = {
  getSummary: trpc.metrics.getSummary,
  getMetrics: trpc.metrics.getMetrics,
  syncAccount: trpc.metrics.syncAccount,
};
