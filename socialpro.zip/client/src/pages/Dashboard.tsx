import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useInstagram } from "@/hooks/useInstagram";
import { LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Instagram, TrendingUp, Users, Eye, Share2, Heart, MessageCircle, Zap, Settings, Plus, Trash2 } from "lucide-react";

import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

// Mock data
const impressionsData = [
  { day: "Seg", impressions: 4200, reach: 2400, engagement: 320 },
  { day: "Ter", impressions: 3000, reach: 1398, engagement: 280 },
  { day: "Qua", impressions: 2000, reach: 9800, engagement: 420 },
  { day: "Qui", impressions: 2780, reach: 3908, engagement: 350 },
  { day: "Sex", impressions: 1890, reach: 4800, engagement: 290 },
  { day: "Sab", impressions: 2390, reach: 3800, engagement: 380 },
  { day: "Dom", impressions: 3490, reach: 4300, engagement: 410 },
];

const engagementData = [
  { type: "Curtidas", value: 4500, fill: "#d946ef" },
  { type: "Comentários", value: 2300, fill: "#06b6d4" },
  { type: "Compartilhamentos", value: 1200, fill: "#8b5cf6" },
  { type: "Salvos", value: 890, fill: "#ec4899" },
];

const audienceData = [
  { day: "Seg", followers: 12500 },
  { day: "Ter", followers: 12650 },
  { day: "Qua", followers: 12800 },
  { day: "Qui", followers: 13100 },
  { day: "Sex", followers: 13450 },
  { day: "Sab", followers: 13800 },
  { day: "Dom", followers: 14200 },
];

const ConnectInstagramButton = () => {
  const getAuthUrl = trpc.instagram.getAuthUrl.useQuery(
    { redirectUri: `${window.location.origin}/api/auth/instagram/callback` },
    { enabled: false }
  );
  const [isLoading, setIsLoading] = useState(false);

  const handleConnect = useCallback(async () => {
    try {
      setIsLoading(true);
      const result = await getAuthUrl.refetch();
      if (result.data?.authUrl) {
        // Listen for message from popup
        const handleMessage = (event: MessageEvent) => {
          if (event.data.type === 'instagram-connected') {
            window.removeEventListener('message', handleMessage);
            toast.success('Conta Instagram conectada com sucesso!');
            // Refresh the page to show new account
            setTimeout(() => {
              window.location.reload();
            }, 1000);
          }
        };
        window.addEventListener('message', handleMessage);
        window.open(result.data.authUrl, 'instagram-auth', 'width=500,height=600');
      } else {
        toast.error('Erro ao gerar URL de autenticacao');
      }
    } catch (error) {
      toast.error('Erro ao conectar com Instagram');
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  }, [getAuthUrl]);

  return (
    <Button
      onClick={handleConnect}
      disabled={isLoading}
      className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 px-8"
    >
      <Instagram className="mr-2 h-4 w-4" />
      {isLoading ? 'Conectando...' : 'Conectar com Instagram'}
    </Button>
  );
};

const KPICard = ({ title, value, icon: Icon, trend, subtext }: any) => (
  <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20 hover:border-secondary/40 transition">
    <CardHeader className="pb-3">
      <div className="flex items-center justify-between">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <Icon className="h-5 w-5 text-secondary" />
      </div>
    </CardHeader>
    <CardContent>
      <div className="text-3xl font-bold">{value}</div>
      <p className="text-xs text-secondary mt-2">{trend}</p>
      {subtext && <p className="text-xs text-muted-foreground mt-1">{subtext}</p>}
    </CardContent>
  </Card>
);

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get("tab") || "dashboard";
  });
  const { data: accounts, isLoading: accountsLoading } = useInstagram.listAccounts.useQuery();

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    setLocation(`/dashboard?tab=${tabId}`);
  };

  const accountsList = accounts && 'accounts' in accounts ? accounts.accounts : [];

  const tabs = [
    { id: "dashboard", label: "Dashboard", icon: "📊" },
    { id: "insights", label: "Insights", icon: "💡" },
    { id: "engagement", label: "Engajamento", icon: "❤️" },
    { id: "connect", label: "Conectar Contas", icon: "🔗" },
    { id: "settings", label: "Configurações", icon: "⚙️" },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">SocialPRO Analytics</h1>
            <p className="text-muted-foreground">Gerencie suas contas Instagram e acompanhe performance em tempo real</p>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 overflow-x-auto pb-2 border-b border-secondary/20">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id)}
              className={`px-4 py-2 whitespace-nowrap rounded-t-lg font-medium transition ${
                activeTab === tab.id
                  ? "bg-gradient-to-r from-primary to-secondary text-white"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div>
          {/* DASHBOARD TAB */}
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              {accountsList.length === 0 ? (
                <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                  <CardContent className="pt-12 pb-12 text-center">
                    <Instagram className="h-16 w-16 text-muted-foreground/30 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Nenhuma conta conectada</h3>
                    <p className="text-muted-foreground mb-6">Conecte sua conta Instagram para começar a analisar suas métricas</p>
                    <Button 
                      onClick={() => setActiveTab("connect")}
                      className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Conectar Conta
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <>
                  {/* KPI Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    <KPICard
                      title="Contas Ativas"
                      value={accountsList.length}
                      icon={Users}
                      trend="Conectadas"
                    />
                    <KPICard
                      title="Total Seguidores"
                      value={(accountsList.reduce((sum: number, acc: any) => sum + (acc.followers || 0), 0) / 1000).toFixed(1) + "K"}
                      icon={Heart}
                      trend="+2.5% este mês"
                    />
                    <KPICard
                      title="Impressões"
                      value="24.5K"
                      icon={Eye}
                      trend="+12.5% vs semana"
                    />
                    <KPICard
                      title="Alcance"
                      value="18.2K"
                      icon={Share2}
                      trend="+8.2% vs semana"
                    />
                    <KPICard
                      title="Engajamento"
                      value="4.2%"
                      icon={TrendingUp}
                      trend="+0.8% vs semana"
                    />
                  </div>

                  {/* Charts */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                      <CardHeader>
                        <CardTitle>Impressões e Alcance</CardTitle>
                        <CardDescription>Últimos 7 dias</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                          <LineChart data={impressionsData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(200,200,200,0.1)" />
                            <XAxis dataKey="day" stroke="rgba(200,200,200,0.5)" />
                            <YAxis stroke="rgba(200,200,200,0.5)" />
                            <Tooltip contentStyle={{ backgroundColor: "rgba(20,20,30,0.9)", border: "1px solid rgba(200,200,200,0.2)" }} />
                            <Legend />
                            <Line type="monotone" dataKey="impressions" stroke="#06b6d4" strokeWidth={2} />
                            <Line type="monotone" dataKey="reach" stroke="#d946ef" strokeWidth={2} />
                          </LineChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                      <CardHeader>
                        <CardTitle>Crescimento de Seguidores</CardTitle>
                        <CardDescription>Últimos 7 dias</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                          <AreaChart data={audienceData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(200,200,200,0.1)" />
                            <XAxis dataKey="day" stroke="rgba(200,200,200,0.5)" />
                            <YAxis stroke="rgba(200,200,200,0.5)" />
                            <Tooltip contentStyle={{ backgroundColor: "rgba(20,20,30,0.9)", border: "1px solid rgba(200,200,200,0.2)" }} />
                            <Area type="monotone" dataKey="followers" stroke="#d946ef" fill="rgba(217, 70, 239, 0.1)" />
                          </AreaChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Contas Conectadas */}
                  <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                    <CardHeader>
                      <CardTitle>Contas Conectadas</CardTitle>
                      <CardDescription>{accountsList.length} conta(s) ativa(s)</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {accountsList.map((account: any) => (
                          <div key={account.id} className="flex items-center justify-between p-4 bg-background/50 rounded-lg border border-secondary/10 hover:border-secondary/30 transition">
                            <div className="flex items-center space-x-4">
                              {account.profilePictureUrl && (
                                <img src={account.profilePictureUrl} alt={account.username} className="w-12 h-12 rounded-full" />
                              )}
                              <div>
                                <p className="font-semibold">@{account.username}</p>
                                <p className="text-sm text-muted-foreground">{account.followers?.toLocaleString() || 0} seguidores</p>
                                {account.bio && <p className="text-xs text-muted-foreground mt-1">{account.bio}</p>}
                              </div>
                            </div>
                            <Button variant="outline" size="sm">
                              Ver Detalhes
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>
          )}

          {/* INSIGHTS TAB */}
          {activeTab === "insights" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <KPICard
                  title="Taxa de Engajamento"
                  value="4.2%"
                  icon={TrendingUp}
                  trend="+0.8% vs semana anterior"
                  subtext="Acima da média da plataforma"
                />
                <KPICard
                  title="Melhor Horário"
                  value="19h-21h"
                  icon={Zap}
                  trend="Pico de atividade"
                  subtext="Maior engajamento neste período"
                />
                <KPICard
                  title="Tipo de Conteúdo"
                  value="Reels"
                  icon={MessageCircle}
                  trend="Melhor performance"
                  subtext="3.2x mais engajamento"
                />
              </div>

              <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                <CardHeader>
                  <CardTitle>Análise de Tráfego Pago</CardTitle>
                  <CardDescription>Performance de campanhas patrocinadas</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="p-4 border border-secondary/20 rounded-lg">
                      <p className="text-sm font-medium text-muted-foreground mb-2">Cliques Totais</p>
                      <p className="text-2xl font-bold">12.5K</p>
                      <p className="text-xs text-secondary mt-2">+15% vs semana anterior</p>
                    </div>
                    <div className="p-4 border border-secondary/20 rounded-lg">
                      <p className="text-sm font-medium text-muted-foreground mb-2">CPC Médio</p>
                      <p className="text-2xl font-bold">R$ 0.45</p>
                      <p className="text-xs text-secondary mt-2">-8% vs semana anterior</p>
                    </div>
                    <div className="p-4 border border-secondary/20 rounded-lg">
                      <p className="text-sm font-medium text-muted-foreground mb-2">ROI Campanhas</p>
                      <p className="text-2xl font-bold">3.8x</p>
                      <p className="text-xs text-secondary mt-2">+0.5x vs semana anterior</p>
                    </div>
                    <div className="p-4 border border-secondary/20 rounded-lg">
                      <p className="text-sm font-medium text-muted-foreground mb-2">Taxa Conversão</p>
                      <p className="text-2xl font-bold">5.2%</p>
                      <p className="text-xs text-secondary mt-2">+1.2% vs semana anterior</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                <CardHeader>
                  <CardTitle>Recomendações Inteligentes</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    <li className="flex items-start space-x-3 p-3 bg-secondary/10 rounded-lg">
                      <span className="text-secondary font-bold">1.</span>
                      <div>
                        <p className="font-medium">Aumente investimento em Reels</p>
                        <p className="text-sm text-muted-foreground">Reels têm 3.2x mais engajamento que posts estáticos</p>
                      </div>
                    </li>
                    <li className="flex items-start space-x-3 p-3 bg-secondary/10 rounded-lg">
                      <span className="text-secondary font-bold">2.</span>
                      <div>
                        <p className="font-medium">Otimize horários de postagem</p>
                        <p className="text-sm text-muted-foreground">Publique entre 19h-21h para máximo alcance</p>
                      </div>
                    </li>
                    <li className="flex items-start space-x-3 p-3 bg-secondary/10 rounded-lg">
                      <span className="text-secondary font-bold">3.</span>
                      <div>
                        <p className="font-medium">Teste público-alvo 25-34 anos</p>
                        <p className="text-sm text-muted-foreground">Segmento com maior potencial de conversão</p>
                      </div>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          )}

          {/* ENGAGEMENT TAB */}
          {activeTab === "engagement" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                  <CardHeader>
                    <CardTitle>Engajamento por Tipo</CardTitle>
                    <CardDescription>Distribuição de interações</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={engagementData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ type, value }) => `${type}: ${value}`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {engagementData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                  <CardHeader>
                    <CardTitle>Engajamento por Dia</CardTitle>
                    <CardDescription>Últimos 7 dias</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={impressionsData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(200,200,200,0.1)" />
                        <XAxis dataKey="day" stroke="rgba(200,200,200,0.5)" />
                        <YAxis stroke="rgba(200,200,200,0.5)" />
                        <Tooltip contentStyle={{ backgroundColor: "rgba(20,20,30,0.9)", border: "1px solid rgba(200,200,200,0.2)" }} />
                        <Bar dataKey="engagement" fill="#d946ef" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                <CardHeader>
                  <CardTitle>Posts com Melhor Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center justify-between p-4 bg-background/50 rounded-lg border border-secondary/10">
                        <div className="flex-1">
                          <p className="font-medium">Post #{i}</p>
                          <p className="text-sm text-muted-foreground">Publicado há {i} dias</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">{2500 * i} engajamentos</p>
                          <p className="text-sm text-secondary">{(4.2 + i * 0.5).toFixed(1)}% taxa</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* CONNECT CONTAS TAB */}
          {activeTab === "connect" && (
            <div className="space-y-6">
              <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                <CardHeader>
                  <CardTitle>Conectar Conta Instagram</CardTitle>
                  <CardDescription>Adicione uma nova conta para começar a analisar</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="p-8 border-2 border-dashed border-secondary/30 rounded-lg text-center">
                    <Instagram className="h-16 w-16 text-secondary/50 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Conecte sua conta Instagram</h3>
                    <p className="text-muted-foreground mb-6">Clique no botão abaixo para autorizar o acesso via OAuth</p>
                    <ConnectInstagramButton />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 border border-secondary/20 rounded-lg">
                      <h4 className="font-semibold mb-2">🔒 Seguro</h4>
                      <p className="text-sm text-muted-foreground">Seus dados são criptografados e seguros</p>
                    </div>
                    <div className="p-4 border border-secondary/20 rounded-lg">
                      <h4 className="font-semibold mb-2">⚡ Rápido</h4>
                      <p className="text-sm text-muted-foreground">Sincronização automática de dados</p>
                    </div>
                    <div className="p-4 border border-secondary/20 rounded-lg">
                      <h4 className="font-semibold mb-2">📊 Completo</h4>
                      <p className="text-sm text-muted-foreground">Acesso a todas as métricas</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {accountsList.length > 0 && (
                <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                  <CardHeader>
                    <CardTitle>Contas Conectadas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {accountsList.map((account: any) => (
                        <div key={account.id} className="flex items-center justify-between p-4 bg-background/50 rounded-lg border border-secondary/10">
                          <div className="flex items-center space-x-4">
                            {account.profilePictureUrl && (
                              <img src={account.profilePictureUrl} alt={account.username} className="w-10 h-10 rounded-full" />
                            )}
                            <div>
                              <p className="font-medium">@{account.username}</p>
                              <p className="text-sm text-muted-foreground">{account.followers?.toLocaleString() || 0} seguidores</p>
                            </div>
                          </div>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* SETTINGS TAB */}
          {activeTab === "settings" && (
            <div className="space-y-6">
              <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                <CardHeader>
                  <CardTitle>Configurações da Conta</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Nome da Conta</label>
                      <input type="text" placeholder="Seu nome" className="w-full mt-2 px-4 py-2 bg-background border border-secondary/20 rounded-lg text-foreground" />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Email</label>
                      <input type="email" placeholder="seu@email.com" className="w-full mt-2 px-4 py-2 bg-background border border-secondary/20 rounded-lg text-foreground" />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Plano Atual</label>
                      <div className="mt-2 p-4 bg-gradient-to-r from-primary/10 to-secondary/10 border border-secondary/20 rounded-lg">
                        <p className="font-semibold">Pro</p>
                        <p className="text-sm text-muted-foreground">5 contas • 50K chamadas/mês</p>
                      </div>
                    </div>
                  </div>
                  <Button className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 w-full">
                    Salvar Configurações
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                <CardHeader>
                  <CardTitle>Notificações</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 border border-secondary/10 rounded-lg">
                    <div>
                      <p className="font-medium">Alertas de Performance</p>
                      <p className="text-sm text-muted-foreground">Notifique quando engajamento cair</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5" />
                  </div>
                  <div className="flex items-center justify-between p-3 border border-secondary/10 rounded-lg">
                    <div>
                      <p className="font-medium">Relatórios Semanais</p>
                      <p className="text-sm text-muted-foreground">Receba resumo semanal por email</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5" />
                  </div>
                  <div className="flex items-center justify-between p-3 border border-secondary/10 rounded-lg">
                    <div>
                      <p className="font-medium">Comentários Novos</p>
                      <p className="text-sm text-muted-foreground">Notifique sobre novos comentários</p>
                    </div>
                    <input type="checkbox" className="w-5 h-5" />
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
                <CardHeader>
                  <CardTitle>Perigo</CardTitle>
                </CardHeader>
                <CardContent>
                  <Button variant="destructive" className="w-full">
                    Desconectar Todas as Contas
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
