import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { BarChart3, Zap, Shield, TrendingUp, Users, Sparkles, ArrowRight, Clock, BarChart4 } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  if (isAuthenticated && user) {
    navigate("/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-card/20">
      {/* Navigation */}
      <nav className="border-b border-secondary/10 bg-background/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BarChart3 className="h-6 w-6 text-secondary" />
            <span className="text-xl font-bold">SocialPRO</span>
          </div>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
          >
            Entrar
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 space-y-8">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Analytics Completo para Instagram
          </h1>
          <p className="text-xl text-muted-foreground">
            Monitore suas contas Instagram, analise métricas em tempo real e otimize seu crescimento com dados precisos.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Button
              size="lg"
              onClick={() => (window.location.href = getLoginUrl())}
              className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
            >
              Começar Agora
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" className="border-secondary/30 hover:bg-secondary/10">
              Ver Demo
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mt-16 max-w-2xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">2.5M+</div>
              <p className="text-sm text-muted-foreground">Impressões Rastreadas</p>
            </div>
            <div className="text-center border-l border-r border-secondary/20">
              <div className="text-3xl font-bold text-primary">1.8M+</div>
              <p className="text-sm text-muted-foreground">Alcance Total</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary">4.2%</div>
              <p className="text-sm text-muted-foreground">Taxa Engajamento</p>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20">
          <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20 hover:border-secondary/40 transition">
            <CardHeader>
              <TrendingUp className="h-8 w-8 text-secondary mb-2" />
              <CardTitle>Métricas em Tempo Real</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Acompanhe impressões, alcance, engajamento e muito mais com dados atualizados constantemente.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20 hover:border-secondary/40 transition">
            <CardHeader>
              <Users className="h-8 w-8 text-secondary mb-2" />
              <CardTitle>Múltiplas Contas</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Gerencie várias contas Instagram em um único painel centralizado e compare desempenho.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20 hover:border-secondary/40 transition">
            <CardHeader>
              <Zap className="h-8 w-8 text-secondary mb-2" />
              <CardTitle>Insights Profundos</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Descubra padrões de engajamento, melhores horários de postagem e otimize sua estratégia.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20 hover:border-secondary/40 transition">
            <CardHeader>
              <Shield className="h-8 w-8 text-secondary mb-2" />
              <CardTitle>Segurança Premium</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Seus dados protegidos com criptografia de ponta a ponta e conformidade LGPD.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20 hover:border-secondary/40 transition">
            <CardHeader>
              <Clock className="h-8 w-8 text-secondary mb-2" />
              <CardTitle>Relatórios Automáticos</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Receba relatórios automáticos semanais e mensais com análises detalhadas.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20 hover:border-secondary/40 transition">
            <CardHeader>
              <BarChart4 className="h-8 w-8 text-secondary mb-2" />
              <CardTitle>Análise de Tráfego Pago</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Monitore campanhas patrocinadas, calcule ROI e otimize seu investimento em publicidade.
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Pricing Preview */}
        <div className="mt-20 space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-2">Planos Simples e Transparentes</h2>
            <p className="text-muted-foreground">Escolha o plano ideal para suas necessidades</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: "Grátis", price: "R$ 0", accounts: "1 conta", features: ["Métricas básicas", "1.000 chamadas/mês"], highlight: false },
              { name: "Grátis", price: "R$ 0", accounts: "1 conta", features: ["Métricas básicas", "1.000 chamadas/mês"] },
              {
                name: "Pro",
                price: "R$ 29",
                accounts: "5 contas",
                features: ["Análise avançada", "50.000 chamadas/mês", "Suporte prioritário"],
                highlight: true,
              },
              { name: "Business", price: "R$ 99", accounts: "20 contas", features: ["IA avançada", "500.000 chamadas/mês", "Suporte 24/7"] },
            ].map((plan, idx) => (
              <Card
                key={idx}
                className={`bg-gradient-to-br from-card to-card/50 border-secondary/20 ${
                  plan.highlight ? "ring-2 ring-secondary" : ""
                }`}
              >
                <CardHeader>
                  <CardTitle>{plan.name}</CardTitle>
                  <CardDescription>{plan.accounts}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-2xl font-bold">{plan.price}</div>
                  <ul className="space-y-2">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="text-sm text-muted-foreground flex items-center">
                        <span className="mr-2 text-secondary">✓</span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="border-t border-secondary/10 bg-gradient-to-r from-primary/10 to-secondary/10 py-20">
        <div className="container mx-auto px-4 text-center space-y-6">
          <h2 className="text-3xl font-bold">Pronto para crescer?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Junte-se a milhares de criadores e marcas que usam SocialPRO para otimizar sua presença no Instagram.
          </p>
          <Button
            size="lg"
            onClick={() => (window.location.href = getLoginUrl())}
            className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
          >
            Começar Gratuitamente
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-secondary/10 bg-background/50 py-8">
        <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
          <p>© 2026 SocialPRO. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
