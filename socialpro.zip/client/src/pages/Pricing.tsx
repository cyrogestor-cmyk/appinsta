import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { usePayments } from "@/hooks/usePayments";
import { Check } from "lucide-react";

export default function Pricing() {
  const { data: plansData } = usePayments.getPlans.useQuery();
  const { data: currentPlan } = usePayments.getCurrentPlan.useQuery();
  const createTransactionMutation = usePayments.createTransaction.useMutation();

  const handleUpgrade = async (planId: "free" | "pro" | "business") => {
    try {
      const result = await createTransactionMutation.mutateAsync({ planId });
      if (result.requiresPayment) {
        console.log("QR Code:", result.qrCode);
        console.log("Copy/Paste:", result.copyPaste);
      }
    } catch (error) {
      console.error("Erro ao criar transação:", error);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Planos e Preços</h1>
          <p className="text-muted-foreground">Escolha o plano ideal para suas necessidades</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plansData?.plans?.map((plan: any) => (
            <Card
              key={plan.id}
              className={`bg-gradient-to-br from-card to-card/50 border-secondary/20 transition ${
                currentPlan?.planId === plan.id ? "ring-2 ring-secondary" : ""
              }`}
            >
              <CardHeader>
                <CardTitle>{plan.name}</CardTitle>
                <CardDescription>{plan.maxAccounts} conta(s) Instagram</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="text-3xl font-bold">
                    {plan.priceCents === 0 ? "Grátis" : `R$ ${(plan.priceCents / 100).toFixed(2)}`}
                  </div>
                  {plan.priceCents > 0 && <p className="text-sm text-muted-foreground">/mês</p>}
                </div>

                <div className="space-y-3">
                  {plan.features?.map((feature: string, idx: number) => (
                    <div key={idx} className="flex items-center space-x-2">
                      <Check className="h-4 w-4 text-secondary" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <Button
                  onClick={() => handleUpgrade(plan.id)}
                  disabled={currentPlan?.planId === plan.id || createTransactionMutation.isPending}
                  className={`w-full ${
                    currentPlan?.planId === plan.id
                      ? "bg-muted text-muted-foreground"
                      : "bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                  }`}
                >
                  {currentPlan?.planId === plan.id ? "Plano Atual" : "Escolher"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
          <CardHeader>
            <CardTitle>Dúvidas?</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Entre em contato conosco para mais informações sobre nossos planos ou suporte customizado.
            </p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
