import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";

export default function Terms() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate(user ? "/dashboard" : "/")}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-xl font-bold text-white">Termos de Serviço</h1>
          <div className="w-20" />
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="prose prose-invert max-w-none">
          <div className="space-y-8 text-slate-300">
            <section>
              <h2 className="text-2xl font-bold text-white mb-4">Termos de Serviço</h2>
              <p className="text-sm text-slate-400 mb-6">
                Última atualização: {new Date().toLocaleDateString("pt-BR")}
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">1. Aceitação dos Termos</h3>
              <p>
                Ao acessar e usar a plataforma SocialPRO, você aceita estar vinculado por estes Termos de Serviço. Se você não concordar
                com qualquer parte destes termos, você não pode usar nosso serviço.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">2. Descrição do Serviço</h3>
              <p>
                A SocialPRO é uma plataforma SaaS que fornece análise de contas Instagram, métricas em tempo real, insights de desempenho
                e ferramentas de gerenciamento. O serviço inclui integração com a API do Instagram Graph e processamento de pagamentos via PIX.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">3. Conta do Usuário</h3>
              <p className="mb-4">
                Você é responsável por:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Manter a confidencialidade de suas credenciais de login</li>
                <li>Notificar-nos imediatamente sobre qualquer acesso não autorizado</li>
                <li>Todas as atividades que ocorrem em sua conta</li>
                <li>Garantir que as informações fornecidas sejam precisas e completas</li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">4. Uso Aceitável</h3>
              <p className="mb-4">
                Você concorda em não usar a plataforma para:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Atividades ilegais ou que violem direitos de terceiros</li>
                <li>Spam, phishing ou ataques de negação de serviço</li>
                <li>Acesso não autorizado a sistemas ou dados</li>
                <li>Engenharia reversa ou tentativa de descobrir código-fonte</li>
                <li>Qualquer atividade que prejudique a plataforma ou outros usuários</li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">5. Propriedade Intelectual</h3>
              <p>
                Todo o conteúdo, recursos e funcionalidades da plataforma SocialPRO, incluindo mas não limitado a software, design,
                gráficos e texto, são propriedade da SocialPRO ou de seus fornecedores de conteúdo e estão protegidos por leis de
                propriedade intelectual internacionais.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">6. Pagamentos e Reembolsos</h3>
              <p className="mb-4">
                Ao se inscrever em um plano pago:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Os pagamentos são processados via PIX através de nosso provedor de pagamento</li>
                <li>As assinaturas são renovadas automaticamente no final de cada período de cobrança</li>
                <li>Você pode cancelar sua assinatura a qualquer momento</li>
                <li>Reembolsos não são fornecidos para períodos parciais</li>
                <li>Todos os preços estão em Real Brasileiro (BRL)</li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">7. Limitação de Responsabilidade</h3>
              <p>
                A SocialPRO não é responsável por danos indiretos, incidentais, especiais ou consequentes resultantes do uso ou
                incapacidade de usar a plataforma, mesmo que tenhamos sido informados da possibilidade de tais danos.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">8. Isenção de Garantias</h3>
              <p>
                A plataforma é fornecida "no estado em que se encontra" sem garantias de qualquer tipo, expressas ou implícitas,
                incluindo mas não limitado a garantias de comercialização ou adequação a um propósito específico.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">9. Interrupção do Serviço</h3>
              <p>
                A SocialPRO pode interromper ou descontinuar o serviço a qualquer momento com aviso prévio. Não somos responsáveis
                por qualquer perda de dados ou interrupção do serviço.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">10. Modificação dos Termos</h3>
              <p>
                A SocialPRO se reserva o direito de modificar estes Termos de Serviço a qualquer momento. As mudanças entrarão em
                vigor imediatamente após a publicação. Seu uso contínuo da plataforma após as alterações constitui aceitação dos
                novos termos.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">11. Lei Aplicável</h3>
              <p>
                Estes Termos de Serviço são regidos pelas leis do Brasil e você concorda em se submeter à jurisdição exclusiva dos
                tribunais brasileiros.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">12. Contato</h3>
              <p>
                Se você tiver dúvidas sobre estes Termos de Serviço, entre em contato conosco em:
              </p>
              <p className="mt-4 font-semibold">
                Email: support@socialpro.com
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
