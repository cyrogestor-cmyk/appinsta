import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useInstagram } from "@/hooks/useInstagram";
import { Instagram, Trash2 } from "lucide-react";
import { useState, useEffect } from "react";

export default function ConnectInstagram() {
  const { data: accounts, isLoading, refetch } = useInstagram.listAccounts.useQuery();
  const handleCallbackMutation = useInstagram.handleCallback.useMutation();
  const disconnectMutation = useInstagram.disconnectAccount.useMutation();
  const [connecting, setConnecting] = useState(false);

  const getAuthUrlQuery = useInstagram.getAuthUrl.useQuery(
    {
      redirectUri: typeof window !== "undefined" ? `${window.location.origin}/api/auth/instagram/callback` : "",
    },
    {
      enabled: false,
    }
  );

  useEffect(() => {
    // Listen for messages from OAuth popup
    const handleMessage = async (event: MessageEvent) => {
      if (event.data.type === "instagram-connected") {
        if (event.data.success) {
          try {
            // Persist the account to database via tRPC
            // The callback endpoint already exchanged the code, so we just need to refetch
            await refetch();
            setConnecting(false);
            alert("✅ Conta Instagram conectada com sucesso!");
          } catch (error) {
            console.error("Erro ao salvar conta:", error);
            alert("Erro ao salvar a conta. Tente novamente.");
            setConnecting(false);
          }
        } else {
          alert(`❌ Erro ao conectar: ${event.data.error}`);
          setConnecting(false);
        }
      }
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [refetch]);

  const handleConnect = async () => {
    setConnecting(true);
    try {
      const { data } = await getAuthUrlQuery.refetch();

      if (data?.authUrl) {
        // Open popup window for OAuth
        const popup = window.open(data.authUrl, "instagram-auth", "width=500,height=600");

        if (!popup) {
          throw new Error("Popup foi bloqueado. Verifique as configurações do navegador.");
        }
      } else {
        throw new Error("Failed to get auth URL");
      }
    } catch (error) {
      console.error("Erro ao conectar Instagram:", error);
      alert("Erro ao conectar ao Instagram. Tente novamente.");
      setConnecting(false);
    }
  };

  const handleDisconnect = async (accountId: number) => {
    try {
      await disconnectMutation.mutateAsync({ accountId });
      await refetch();
    } catch (error) {
      console.error("Erro ao desconectar:", error);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Conectar Instagram</h1>
          <p className="text-muted-foreground">Gerencie suas contas Instagram conectadas</p>
        </div>

        <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
          <CardHeader>
            <CardTitle>Adicionar Conta</CardTitle>
            <CardDescription>Conecte uma nova conta Instagram para começar a analisar</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={handleConnect}
              disabled={connecting}
              className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
            >
              <Instagram className="mr-2 h-4 w-4" />
              {connecting ? "Conectando..." : "Conectar Instagram"}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
          <CardHeader>
            <CardTitle>Contas Conectadas</CardTitle>
            <CardDescription>{accounts && "accounts" in accounts ? accounts.accounts.length : 0} conta(s) ativa(s)</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-muted-foreground">Carregando...</p>
            ) : accounts && "accounts" in accounts && accounts.accounts.length > 0 ? (
              <div className="space-y-4">
                {accounts.accounts.map((account: any) => (
                  <div
                    key={account.id}
                    className="flex items-center justify-between p-4 bg-background/50 rounded-lg border border-secondary/10 hover:border-secondary/30 transition"
                  >
                    <div className="flex items-center space-x-4">
                      {account.profilePictureUrl && (
                        <img
                          src={account.profilePictureUrl}
                          alt={account.username}
                          className="w-12 h-12 rounded-full"
                        />
                      )}
                      <div>
                        <p className="font-medium">@{account.username}</p>
                        <p className="text-sm text-muted-foreground">{account.followers.toLocaleString()} seguidores</p>
                        {account.bio && <p className="text-xs text-muted-foreground mt-1">{account.bio}</p>}
                      </div>
                    </div>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDisconnect(account.id)}
                      disabled={disconnectMutation.isPending}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-8">Nenhuma conta conectada</p>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
