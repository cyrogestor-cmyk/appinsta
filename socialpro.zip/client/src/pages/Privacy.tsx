import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";

export default function Privacy() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700/50 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate(user ? "/dashboard" : "/")}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-xl font-bold text-white">Política de Privacidade</h1>
          <div className="w-20" />
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="prose prose-invert max-w-none">
          <div className="space-y-8 text-slate-300">
            <section>
              <h2 className="text-2xl font-bold text-white mb-4">Política de Privacidade</h2>
              <p className="text-sm text-slate-400 mb-6">
                Última atualização: {new Date().toLocaleDateString("pt-BR")}
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">1. Introdução</h3>
              <p>
                A SocialPRO ("nós", "nosso" ou "nos") opera a plataforma SocialPRO. Esta página informa você sobre nossas políticas
                sobre a coleta, uso e divulgação de dados pessoais quando você usa nosso serviço e as escolhas que você tem associadas
                a esses dados.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">2. Dados que Coletamos</h3>
              <p className="mb-4">Coletamos os seguintes tipos de dados:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>
                  <strong>Dados de Conta:</strong> Nome, email, senha criptografada e informações de perfil
                </li>
                <li>
                  <strong>Dados do Instagram:</strong> Informações de contas conectadas, métricas, insights e dados de desempenho
                </li>
                <li>
                  <strong>Dados de Pagamento:</strong> Informações de transações PIX (processadas de forma segura)
                </li>
                <li>
                  <strong>Dados de Uso:</strong> Logs de acesso, atividades e interações com a plataforma
                </li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">3. Como Usamos Seus Dados</h3>
              <p className="mb-4">Usamos os dados coletados para:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Fornecer e manter nossos serviços</li>
                <li>Processar transações e enviar notificações relacionadas</li>
                <li>Melhorar, personalizar e expandir nossos serviços</li>
                <li>Comunicar com você sobre atualizações, promoções e ofertas</li>
                <li>Detectar e prevenir fraudes e atividades ilícitas</li>
                <li>Cumprir obrigações legais</li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">4. Compartilhamento de Dados</h3>
              <p className="mb-4">
                Compartilhamos seus dados apenas quando necessário:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>
                  <strong>Com Provedores de Serviços:</strong> Parceiros que nos ajudam a operar a plataforma (ex: processadores de pagamento)
                </li>
                <li>
                  <strong>Com Requisitos Legais:</strong> Quando exigido por lei ou para proteger nossos direitos
                </li>
                <li>
                  <strong>Consentimento:</strong> Quando você consentir explicitamente
                </li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">5. Segurança dos Dados</h3>
              <p>
                Implementamos medidas de segurança técnicas e organizacionais para proteger seus dados pessoais contra acesso não autorizado,
                alteração, divulgação ou destruição. Isso inclui criptografia, firewalls e controle de acesso.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">6. Seus Direitos</h3>
              <p className="mb-4">
                Você tem o direito de:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Acessar seus dados pessoais</li>
                <li>Corrigir dados imprecisos</li>
                <li>Solicitar a exclusão de seus dados</li>
                <li>Optar por não receber comunicações de marketing</li>
                <li>Solicitar a portabilidade de seus dados</li>
              </ul>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">7. Retenção de Dados</h3>
              <p>
                Retemos seus dados pessoais pelo tempo necessário para fornecer nossos serviços e cumprir obrigações legais.
                Você pode solicitar a exclusão de seus dados a qualquer momento.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">8. Cookies e Rastreamento</h3>
              <p>
                Usamos cookies e tecnologias similares para melhorar sua experiência, autenticar usuários e analisar o uso da plataforma.
                Você pode controlar as configurações de cookies em seu navegador.
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">9. Contato</h3>
              <p>
                Se você tiver dúvidas sobre esta Política de Privacidade ou nossas práticas de privacidade, entre em contato conosco em:
              </p>
              <p className="mt-4 font-semibold">
                Email: privacy@socialpro.com
              </p>
            </section>

            <section>
              <h3 className="text-xl font-semibold text-white mb-3">10. Alterações a Esta Política</h3>
              <p>
                Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos você sobre mudanças significativas publicando
                a nova política em nosso site e atualizando a data de "Última atualização" acima.
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
