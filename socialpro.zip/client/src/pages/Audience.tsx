import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Audience() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Audiência</h1>
          <p className="text-muted-foreground">Análise detalhada do seu público</p>
        </div>

        <Card className="bg-gradient-to-br from-card to-card/50 border-secondary/20">
          <CardHeader>
            <CardTitle>Dados de Audiência</CardTitle>
            <CardDescription>Informações sobre seus seguidores</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Recursos em desenvolvimento...</p>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
